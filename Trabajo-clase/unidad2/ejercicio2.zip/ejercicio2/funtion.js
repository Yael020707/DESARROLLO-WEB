// Selección de elementos del DOM
const themeToggleBtn = document.getElementById('btnToggleTheme');
const changeColorsBtn = document.getElementById('btnChangeColors');
const colorBoxes = document.querySelectorAll('.box');

themeToggleBtn.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});

const colorPalettes = [
    // Paleta 1 (Original)
    ['#ef4444', '#e11d48', '#f97316', '#3b82f6', '#78350f', '#22c55e', '#eab308'],
    // Paleta 2 (Neón / Cyber)
    ['#ff0055', '#ff00aa', '#ff5500', '#0099ff', '#884400', '#00cc66', '#ffee00'],
    // Paleta 3 (Pastel vibrante)
    ['#f43f5e', '#d946ef', '#fb923c', '#38bdf8', '#a16207', '#4ade80', '#fde047'],
    // Paleta 4 (Retro arcade)
    ['#ea580c', '#c084fc', '#eab308', '#0284c7', '#713f12', '#15803d', '#facc15']
];